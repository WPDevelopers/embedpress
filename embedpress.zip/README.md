# EmbedPress
EmbedPress is a WordPress plugin that are capable of embedding media from over 150+ providers into a WordPress site.

# Table of Contents
- [New Releases](https://github.com/WPDevelopers/embedpress/releases)
- [Supported Service Providers](https://github.com/WPDevelopers/Embera/blob/master/doc/02-providers.md)
- [Changelog](https://github.com/WPDevelopers/embedpress/releases)

# For Build by WP-CLI
Run the command below from WordPress root folder.

`wp dist-archive wp-content/plugins/embedpress embedpress`
